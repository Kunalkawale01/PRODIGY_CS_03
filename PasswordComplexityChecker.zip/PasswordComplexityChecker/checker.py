
import re

def check_password_strength(password):
    score = 0
    messages = []

    if len(password) >= 8:
        score += 1
    else:
        messages.append("Password should be at least 8 characters long.")

    if re.search(r"[A-Z]", password):
        score += 1
    else:
        messages.append("Add at least one uppercase letter.")

    if re.search(r"[a-z]", password):
        score += 1
    else:
        messages.append("Add at least one lowercase letter.")

    if re.search(r"[0-9]", password):
        score += 1
    else:
        messages.append("Add at least one number.")

    if re.search(r"[!@#$%^&*(),.?":{}|<>]", password):
        score += 1
    else:
        messages.append("Add at least one special character.")

    if score <= 2:
        level = "Weak"
    elif score == 3 or score == 4:
        level = "Medium"
    else:
        level = "Strong"

    return score, {
        "level": level,
        "messages": messages if messages else ["Your password is strong."]
    }
