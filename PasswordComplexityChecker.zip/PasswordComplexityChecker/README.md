
# Password Complexity Checker

## Description
A Python-based tool that evaluates the strength of a password based on
length, uppercase letters, lowercase letters, numbers, and special characters.

## Features
- Password strength scoring
- Detailed feedback
- Simple CLI interface

## How to Run
python main.py
