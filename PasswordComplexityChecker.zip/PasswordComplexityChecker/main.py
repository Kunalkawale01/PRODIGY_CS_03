
from checker import check_password_strength

def main():
    print("=" * 45)
    print("     PASSWORD COMPLEXITY CHECKER")
    print("=" * 45)

    password = input("Enter a password to check: ")
    score, feedback = check_password_strength(password)

    print("\nPassword Strength Score:", score, "/ 5")
    print("Strength Level:", feedback["level"])
    print("\nFeedback:")
    for msg in feedback["messages"]:
        print("-", msg)

if __name__ == "__main__":
    main()
